from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class PlanSession:
    """
    Server-side planning session handle returned by ``PlanningClient.plan``.

    Stage 1 stores only scenario metadata. Later stages will add methods such
    as ``prepare_candidates()``, ``compute_metrics()``, ``solve()`` and
    ``evaluate()`` while keeping notebook code compact.
    """

    client: Any
    name: str
    planner: str
    scenario_id: str
    summary: dict[str, Any] = field(default_factory=dict)
    validation_errors: list[str] = field(default_factory=list)
    scenario: dict[str, Any] | None = None

    @property
    def ok(self) -> bool:
        """Return true when the server accepted the scenario without errors."""
        return not self.validation_errors

    def refresh(self) -> "PlanSession":
        """
        Reload scenario metadata from the server.

        This is useful when another notebook cell or MCP action modifies the
        same server-side scenario.
        """
        payload = self.client._request(
            "get",
            f"/planning/scenarios/{self.scenario_id}",
        )
        data = payload["data"]
        self.summary = data.get("summary", {})
        self.validation_errors = data.get("validation_errors", [])
        self.scenario = data.get("scenario")
        return self
