from __future__ import annotations

from pathlib import Path
from typing import Any
from uuid import uuid4

import requests

from cisei_planning_sdk.bundle import load_scenario_bundle
from cisei_planning_sdk.session import PlanSession


class PlanningClient:
    """
    High-level notebook client for the planning microservice.

    The notebook user should work with this class instead of importing server
    internals. Stage 1 is ``plan(...)``: load a local scenario bundle, define
    it on the server, and return a ``PlanSession`` that will later expose the
    next planning stages.
    """

    def __init__(
        self,
        base_url: str,
        *,
        user_id: str | None = None,
        token: str | None = None,
        auto_register: bool = True,
        timeout: float = 120.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.user_id = user_id or f"notebook-{uuid4().hex[:12]}"
        self.token = token
        self.timeout = timeout
        self.session = requests.Session()
        if auto_register and self.token is None:
            self.connect()

    def connect(self, *, reset: bool = True) -> "PlanningClient":
        """
        Register this notebook session with the planning hub.

        The hub returns a per-user token and starts/refreshes the worker on the
        first authenticated planning request. ``reset=True`` keeps the current
        hub behavior: registering the same user id replaces its worker state.
        """
        response = self.session.post(
            f"{self.base_url}/register",
            params={"user_id": self.user_id},
            timeout=self.timeout,
        )
        response.raise_for_status()
        payload = response.json()
        self.user_id = payload["user_id"]
        self.token = payload["token"]
        return self

    def plan(
        self,
        *,
        name: str,
        planner: str,
        scenario: str | Path | dict[str, Any],
    ) -> PlanSession:
        """
        Define a planning scenario on the server and return a session handle.

        Parameters
        ----------
        name:
            Stable server-side scenario id.
        planner:
            Planner kind to remember for the next stages, usually ``"cell"``
            or ``"graph"``.
        scenario:
            Either a local TOML bundle path or a complete scenario dictionary.
            When a TOML bundle declares ``[instances].source``, the SDK reads
            the companion CSV locally and embeds concrete ``sites`` in the JSON
            sent to the server.
        """
        scenario_json = self._scenario_json(scenario)
        response = self._request(
            "post",
            "/planning/scenarios/define",
            json={
                "scenario_id": name,
                "scenario": scenario_json,
            },
        )
        data = response["data"]
        return PlanSession(
            client=self,
            name=name,
            planner=planner,
            scenario_id=data["scenario_id"],
            summary=data.get("summary", {}),
            validation_errors=data.get("validation_errors", []),
            scenario=data.get("scenario"),
        )

    def define_scenario(
        self,
        *,
        name: str,
        scenario: str | Path | dict[str, Any],
        planner: str = "graph",
    ) -> PlanSession:
        """
        Alias for ``plan(...)`` when the caller wants explicit stage wording.
        """
        return self.plan(name=name, planner=planner, scenario=scenario)

    def _scenario_json(
        self,
        scenario: str | Path | dict[str, Any],
    ) -> dict[str, Any]:
        if isinstance(scenario, (str, Path)):
            return load_scenario_bundle(scenario)
        if isinstance(scenario, dict):
            return _json_value(scenario)
        raise TypeError("scenario must be a TOML path or dictionary")

    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        url = self._url(path)
        headers = dict(kwargs.pop("headers", {}) or {})
        if self.token:
            headers["X-Token"] = self.token

        response = self.session.request(
            method,
            url,
            headers=headers,
            timeout=self.timeout,
            **kwargs,
        )
        response.raise_for_status()

        payload = response.json()
        if str(payload.get("status", "")).lower() != "ok":
            raise RuntimeError(payload.get("data", payload))
        return payload

    def _url(self, path: str) -> str:
        path = "/" + path.lstrip("/")
        if self.user_id:
            return f"{self.base_url}/{self.user_id}{path}"
        return f"{self.base_url}{path}"


def _json_value(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_json_value(item) for item in value]
    if isinstance(value, list):
        return [_json_value(item) for item in value]
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if value == value and value not in {float("inf"), float("-inf")} else None
    return value
